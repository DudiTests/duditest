These are sample AWS Cloudformation templates. These are provided as basic examples. They leverage the generic Linux scripts available [here](https://github.com/mreferre/yelb/tree/master/deployments/platformdeployment/Linux). These templates only work in selected regions (those for which mappings to proper AMIs has been explicitly included). Should you need to run them in other regions, you can map the Amazon Linux AMI for that region.  

This is a work in progress.
