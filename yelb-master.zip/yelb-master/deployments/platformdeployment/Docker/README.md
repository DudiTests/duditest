These configurations had been lightly tested against Docker for Mac (configured as a single node Swarm cluster).

These two scripts should work against a simple docker host (which includes support for `Swarm legacy` clusters) as well as a `Swarm mode` cluster.

This is a WIP.
