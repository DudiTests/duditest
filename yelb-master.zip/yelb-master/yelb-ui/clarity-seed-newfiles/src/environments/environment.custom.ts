export const environment = {
  production: true,
  envName: 'custom',
  appserver_env: 'http://' + 'YELB_APPSERVER_ENDPOINT'
};
