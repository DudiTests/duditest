export const environment = {
  production: true,
  envName: 'prod',
  appserver_env: 'http://' + window.location.host
};
